<?php
/**
 * @file home.php
 * 
 * @description This file handles the integration settings for the `quizaccess_plugin_dora` plugin.
 * It provides an interface to manage the plugin's credentials and integration status with an external service.
 * The file includes forms for submitting credentials, saving them to the database, and handling API responses.
 *
 * @author Alex Lopez <email>
 * @date 2024-11-26
 */
require_once(__DIR__ . '/../../../../config.php');

//TODO modificar a rutas absolutas y no relativas

require_once($CFG->dirroot . '/mod/quiz/accessrule/plugin_dora/form_settings.php');

//require_capability('moodle/site:config', $context);

// Requiere el permiso de administrador para acceder a esta página.
require_login();
$context = context_system::instance(); // Define el contexto del sistema o el adecuado
$PAGE->set_context($context); // Establece el contexto de la página
$PAGE->set_url(new moodle_url('/mod/quiz/accessrule/plugin_dora/home.php')); // Define la URL de la página
$PAGE->set_pagelayout('admin'); // Usa un diseño adecuado ('standard', 'admin', etc.)
// Título de la página personalizada.
$pagetitle = get_string('monitoring', 'quizaccess_plugin_dora');
$activateErrorHtml = '';

$mform = new dora_settings_form('home.php');

if ($mform->is_cancelled()) {
    echo "";
} else if ($data = $mform->get_data()) {
    global $DB, $CFG;

    try {
        $moodleurl = $CFG->wwwroot; // Obtiene la URL de la instancia de Moodle
        $monitoringcredentials = new stdClass();
        $monitoringcredentials->plugin_dora_key = trim($data->plugin_dora_key);
        $monitoringcredentials->plugin_dora_secret = trim($data->plugin_dora_secret);

        //  Verificar si la tabla monitoring_integration existe antes de acceder
        if (!$DB->get_manager()->table_exists('monitoring_integration')) {
            debugging("Error: La tabla 'monitoring_integration' no existe.", DEBUG_DEVELOPER);
            echo html_writer::div("Error: No se encontró la configuración de integración.", 'alert alert-danger');
            return;
        }

        //  Consultar si el registro con id=1 existe
        $record = $DB->get_record('monitoring_integration', ['id' => 1]);

        //  Llamar a la API para validar credenciales
        $responsedata = validate_monitoring_credentials($moodleurl, $monitoringcredentials->plugin_dora_key, $monitoringcredentials->plugin_dora_secret);
        echo "<script>console.log('Response data: " . htmlspecialchars(json_encode($responsedata), ENT_QUOTES, 'UTF-8') . "');</script>";

        if (!$responsedata || !isset($responsedata->status)) {
            debugging("Error: No se recibió una respuesta válida de la API.", DEBUG_DEVELOPER);
            echo html_writer::div("Error: No se pudo validar la integración.", 'alert alert-danger');
            return;
        }

        //  Crear o actualizar el registro en la base de datos
        if ($responsedata->status == 200) {
            $record = $record ?: new stdClass(); // Crear nuevo si no existe
            $record->id = 1;
            $record->plugin_dora_key = $monitoringcredentials->plugin_dora_key;
            $record->plugin_dora_status = 1;

            if ($DB->record_exists('monitoring_integration', ['id' => 1])) {
                $DB->update_record('monitoring_integration', $record);
            } else {
                $DB->insert_record('monitoring_integration', $record);
            }
        } else {
            debugging("Advertencia: Credenciales no válidas.", DEBUG_DEVELOPER);
            $record = new stdClass();
            $record->id = 1;
            $record->plugin_dora_status = 0;

            if ($DB->record_exists('monitoring_integration', ['id' => 1])) {
                $DB->update_record('monitoring_integration', $record);
            } else {
                $DB->insert_record('monitoring_integration', $record);
            }
//            echo html_writer::div("Advertencia: Credenciales incorrectas.", 'alert alert-warning');
            echo "<script>alert('Credenciales incorrectas.');</script>";

        }

        //  Almacenar estado global
        if (!isset($GLOBALS['MONI'])) {
            $GLOBALS['MONI'] = new stdClass();
        }
        $GLOBALS['MONI']->plugin_dora_status = $record->plugin_dora_status;

    }catch (Exception $e) {
        debugging($e->getMessage(), DEBUG_DEVELOPER);
        echo html_writer::div($e->getMessage(), 'alert alert-danger');
    }
}

$record2 = $DB->get_record('monitoring_integration', array('id' => 1));
echo "<script>console.log('record2: " . json_encode($record2) . "');</script>";

if (isset($_POST['cambiar_estado'])) {
    
    if ($record2->plugin_dora_status) {
        $content = '<p>DORA se encuentra activo.</p>';

        // Imprime la página personalizada.
        echo $OUTPUT->header();
        echo $OUTPUT->heading($pagetitle);
        echo $content;
        $mform->display();
    
        echo $OUTPUT->footer();

    } else {
        $content = '<p>DORA se encuentra inactivo, para activarlo agrega una llave y una clave.</p>';

        // Imprime la página personalizada.
        echo $OUTPUT->header();
        echo $OUTPUT->heading($pagetitle);
        echo $content;
        $mform->display();
    
        echo $OUTPUT->footer();
    }
} else {
    $content = '<p>En este pagina puedes administrar tu integración.<br>A continuación se muestra el estado actual de la integración.</p>';
    $textoBoton = "Registrar Credenciales";
    $status_int = "Inactiva";
    $tipo_licencia = "Inactiva";
    $clave_pro = "Sin clave";

    $badged_status = "danger";
    $badged_tipo = "danger";
    $badged_clave = "danger";

    if ($record2->plugin_dora_status == 1) {
        $textoBoton = "Actualizar Credenciales";
        $tipo_licencia = "Activa";
        $status_int = "Activa";
        $clave_pro = "Activa";

        $badged_status = "success";
        $badged_tipo = "success";
        $badged_clave = "success";
    }

    echo $OUTPUT->header();
    echo $OUTPUT->heading($pagetitle);
    echo $content;

    echo '<div class="col-md-5">
            <ul class="list-group">

            <li class="list-group-item d-flex justify-content-between">
                <span>Estado de la integración</span>
                <span class="badge badge-'.$badged_status.' p-1">'.$status_int.'</span>
            </li>
            <li class="list-group-item d-flex justify-content-between">
                <span>Clave del producto</span>
                <span class="badge badge-'.$badged_clave.' p-1">'.$clave_pro.'</span>
            </li>
            </ul>
            <form method="post" class="d-flex justify-content-between">
                <div>
                </div>
                <button class="btn btn-primary mt-3" type="submit" name="cambiar_estado">'.$textoBoton.'</button>
            </form>
        </div>
        ';

    echo $OUTPUT->footer();

}
/**
 * @purpose Validate the provided monitoring credentials by making a POST request to an external API.
 * This function sends the credentials (API key and secret) along with the Moodle URL to an external 
 * service to check if the credentials are valid.
 *
 * @param string $moodleUrl The Moodle instance URL.
 * @param string $key The API key for the plugin.
 * @param string $secret The API secret for the plugin.
 * @returns object The response from the external API, decoded from JSON.
 */
function validate_monitoring_credentials($moodleUrl, $key, $secret) {
    global $CFG;

    // Configuración de la URL de la API
    $apiurl = 'https://apidora.aionis.net/api/plugin/register-moodle-hash-institution';
    $data = [
        'moodleUrl' => $moodleUrl,
        'moodleKey' => $key,
        'moodlePassword' => $secret
    ];

    // Convertir los datos a JSONF
    $jsondata = json_encode($data);

    // Inicializar cURL
    $ch = curl_init($apiurl);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $jsondata,
        CURLOPT_HTTPHEADER => [
            'Content-Type: application/json',
            'Content-Length: ' . strlen($jsondata)
        ],
        CURLOPT_TIMEOUT => 10, // Tiempo de espera de 10 segundos
        CURLOPT_CONNECTTIMEOUT => 5, // Tiempo de espera para conectar

        // Configuración SSL
        CURLOPT_SSL_VERIFYPEER => true, // Verificar el certificado SSL
        CURLOPT_SSL_VERIFYHOST => 2, // Verificar que el host coincida con el certificado

        // Si estás en un entorno local con XAMPP/WAMP, descomenta esta línea:
//        CURLOPT_CAINFO => $CFG->dirroot . '/cacert.pem',
    ]);

    // Ejecutar la solicitud
    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    if ($response === false) {
        $error = curl_error($ch);
        debugging("cURL Error: $error", DEBUG_DEVELOPER);
        echo html_writer::div("Error al conectar con la API: $error", 'alert alert-danger');
        curl_close($ch);
        return false;
    } else {
        debugging("Respuesta de la API ($http_code): $response", DEBUG_DEVELOPER);
        echo "<script>console.log('Respuesta API: " . addslashes($response) . "');</script>";

        if ($http_code >= 400) {
            debugging("Error en la respuesta de la API (HTTP $http_code): $response", DEBUG_DEVELOPER);
        }
    }
    curl_close($ch);
    return json_decode($response);
}
//function generate_encryption_key() {
//    // Usamos una clave fija más un hash de la URL de Moodle como base
//    return hash('sha256', 'DoraPluginSalt' . $_SERVER['HTTP_HOST'], true);
//}
//
//function encrypt_data($data) {
//    $key = generate_encryption_key();
//    $iv = openssl_random_pseudo_bytes(16);
//    $encrypted = openssl_encrypt($data, 'AES-256-CBC', $key, 0, $iv);
//    return base64_encode($iv . $encrypted);
//}

