<?php
// Buscar automáticamente la ruta de config.php sin importar la ubicación del plugin
//$path = __DIR__;
//while (!file_exists($path . '/config.php') && $path !== dirname($path)) {
//    $path = dirname($path);
//}
require_once(__DIR__ . '/../../../../config.php');

// Verificar si el usuario tiene permisos
require_login();
if (!is_siteadmin()) {
    print_error('accessdenied', 'admin');
}

// Redirigir a la página principal del plugin
redirect($CFG->wwwroot . '/mod/quiz/accessrule/plugin_dora/home.php');
exit;