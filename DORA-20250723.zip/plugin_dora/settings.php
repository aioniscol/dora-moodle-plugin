<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * @File        settings.php
 *
 * @description This file defines administrative pages and settings for the plugin.
 *              It integrates the plugin’s settings into Moodle's administration interface.
 *
 * @author      Alex Lopez <email>
 * @date        2024-11-26
 *
 * @package     quizaccess_plugin_dora
 * @category    admin
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

GLOBAL $PAGE, $CFG;

// Verificar si el usuario tiene acceso a la configuración del sitio
if ($hassiteconfig) {
    // Definir la categoría padre correcta en Moodle
    $parent_category = 'modsettings'; // Esta categoría existe en Moodle por defecto

    // Verificar si la categoría existe antes de agregar configuraciones
    if (!$ADMIN->locate($parent_category)) {
        debugging("Categoría padre '$parent_category' no existe. Verifica la estructura de administración en Moodle.", DEBUG_DEVELOPER);
    } else {
        /**
         * @purpose Agrega una página externa en la administración de Moodle para este plugin.
         *
         * @param    string $name      Identificador único de la configuración.
         * @param    string $title     Nombre que aparecerá en la interfaz de administración.
         * @param    string $url       URL de la página de configuración del plugin.
         */
        $settings = new admin_externalpage(
            'quizaccess_monitoring_settings',
            get_string('pluginname', 'quizaccess_plugin_dora'),
            new moodle_url('/mod/quiz/accessrule/plugin_dora/home.php')
        );

        // Agregar la configuración dentro de la categoría correcta en Moodle
        $ADMIN->add($parent_category, $settings);
    }
}

// Comportamiento de redirección (desactivado por ahora)
if (isset($PAGE->url) && strpos($PAGE->url, "section=modsettingsquizcatplugin_dora") !== false) {
    // redirect($CFG->wwwroot . '/mod/quiz/accessrule/plugin_prueba/home.php');
}
