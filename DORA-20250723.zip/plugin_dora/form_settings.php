<?php
/**
 * @file form_settings.php
 * 
 * @description This file defines the settings form for the plugin `quizaccess_plugin_dora`.
 * It provides an interface for administrators to input the API key and secret key required 
 * for the integration with an external system.
 *
 * @author Alex Lopez <email>
 * @date 2024-11-26
 */

defined('MOODLE_INTERNAL') || die();

require_once($CFG->libdir . '/formslib.php');
/**
 * Class for the settings form of the `quizaccess_plugin_dora` plugin.
 * This class extends moodleform to create a form that collects the API key and secret key 
 * required by the plugin.
 *
 * @package quizaccess_plugin_dora
 * @license http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class dora_settings_form extends moodleform {
    /**
     * @purpose Define the elements and validation rules of the settings form for the plugin.
     * This method adds fields for the API key and secret key, both of which are required 
     * for integration with an external system. It also adds action buttons for submitting 
     * or canceling the form.
     *
     * @param void
     * @returns void
     */
    protected function definition() {
        $mform = $this->_form;
        //key
        $mform->addElement('text', 'plugin_dora_key', get_string('llave', 'quizaccess_plugin_dora'));
        $mform->addRule('plugin_dora_key', get_string('llave_desc', 'quizaccess_plugin_dora'),
                'required', null, 'client');
        $mform->setType('plugin_dora_key', PARAM_ALPHANUMEXT); // O el tipo adecuado
        $mform->addHelpButton('plugin_dora_key', 'llave', 'quizaccess_plugin_dora'); // Agregar ayuda

        //secret
        $mform->addElement('text', 'plugin_dora_secret', get_string('clave', 'quizaccess_plugin_dora'));
        $mform->addRule('plugin_dora_secret', get_string('clave_desc', 'quizaccess_plugin_dora'),
                'required', null, 'client');
        $mform->setType('plugin_dora_secret', PARAM_RAW); // O un tipo más seguro si aplica
        $mform->addHelpButton('plugin_dora_secret', 'clave', 'quizaccess_plugin_dora'); // Agregar ayuda

        $this->add_action_buttons(false);
    }

    // Validación personalizada de campos
    public function validation($data, $files) {
        $errors = [];

        if (empty(trim($data['plugin_dora_key']))) {
            $errors['plugin_dora_key'] = 'Debe ingresar una clave válida.';
        }

        if (empty(trim($data['plugin_dora_secret']))) {
            $errors['plugin_dora_secret'] = 'Debe ingresar un secreto válido.';
        }
        // Mostrar la alerta solo si hay errores
        if (!empty($errors)) {
            echo "<script>alert('Debe ingresar la clave y el secreto antes de validar.');</script>";
        }

        return $errors;
    }

}