<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * This file contains language strings for the plugin. These strings are used in 
 * the user interface (UI) to display readable text in a specific language, in this case, English.
 *
 * @package     quizaccess_plugin_dora
 * @category    string
 * @copyright   2024 Your Name <you@example.com>
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();
$string['pluginname'] = 'DORA';
$string['monitoring'] = 'Configuración de integración DORA';

$string['plugin_dora_setting'] = 'Configuración DORA';
$string['plugin_dora_enable'] = 'Enable Plugin Prueba';

//Configuración nueva de DORA
$string['plugin_dora_setting_help'] = 'Esta configuración permite habilitar o deshabilitar las restricciones de DORA.';
$string['restriction_fullscreen'] = 'Forzar pantalla completa al iniciar el examen.';
$string['restriction_fullscreen_help'] = 'Obliga a los usuarios a presentar el examen en modo de pantalla completa.';
$string['restriction_print'] = 'Bloquear impresión.';
$string['restriction_print_help'] = 'Evita que los usuarios impriman el contenido del examen.';
$string['restriction_paste'] = 'Bloquear pegar.';
$string['restriction_paste_help'] = 'Impide que los usuarios puedan pegar texto dentro del examen.';
$string['restriction_rightclick'] = 'Bloquear clic derecho.';
$string['restriction_rightclick_help'] = 'Deshabilita el clic derecho para prevenir accesos contextuales.';
$string['restriction_copy'] = 'Bloquear copiar.';
$string['restriction_copy_help'] = 'Evita que los usuarios copien contenido del examen.';
$string['restriction_traslate'] = 'Bloquear traducciones.';
$string['restriction_traslate_help'] = 'Deshabilita servicios de traducción automática dentro del examen.';
$string['restriction_detectalt'] = 'Detectar tecla ALT.';
$string['restriction_detectalt_help'] = 'Monitorea el uso de la tecla ALT para prevenir accesos no autorizados.';
$string['restriction_selecttext'] = 'Deshabilitar selección de texto.';
$string['restriction_selecttext_help'] = 'Evita que los usuarios seleccionen texto dentro del examen.';
$string['restriction_resize'] = 'Bloquear redimensionamiento.';
$string['restriction_resize_help'] = 'Impide cambiar el tamaño de la ventana del navegador.';
$string['restriction_download'] = 'Bloquear descargas.';
$string['restriction_download_help'] = 'Evita que los usuarios descarguen contenido del examen.';
$string['restriction_onlinerecognition'] = 'Habilitar reconocimiento facial.';
$string['restriction_onlinerecognition_help'] = 'Activa la detección facial para verificar la identidad del usuario durante el examen.';
$string['single_monitor'] = 'Permitir solo un monitor.';
$string['single_monitor_help'] = 'Limita el uso a un solo monitor conectado.';
$string['window_change'] = 'Bloquear cambio de ventana.';
$string['window_change_help'] = 'Detecta y previene cambios de ventana durante el examen.';
$string['deterrent_mode'] = 'Activar modo disuasorio.';
$string['deterrent_mode_help'] = 'Activa el complemento de DORA para el estudiante pero no hace el monitoreo del examen por lo tanto no consume licencias.';
$string['focus_exam'] = 'Requiere atención constante.';
$string['focus_exam_help'] = 'Monitorea que los usuarios mantengan el enfoque constante en la ventana del examen.';

$string['llave'] = 'Llave';
$string['llave_desc'] = 'Introduce la llave.';
$string['llave_help'] = "La llave es un identificador que el administrador de Moodle puede definir libremente. Puedes ingresar 
        cualquier valor que desees, pero se recomienda usar un nombre claro y fácil de recordar";
$string['clave'] = 'Clave';
$string['clave_desc'] = 'Introduce la clave.';
$string['clave_help'] = "La clave es un valor único proporcionado por el equipo de soporte. Esta clave es necesaria para autenticar la integración con el 
        sistema de monitoreo. Si no la tienes, contacta con soporte técnico.";