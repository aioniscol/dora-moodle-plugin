<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * @File rule.php
 * 
 * @description This file defines the access rules for a quiz in Moodle, allowing
 *              custom restrictions and conditions based on plugin configuration.
 *              It integrates with Moodle's quiz module to apply specific rules 
 *              during the attempt phase.
 * 
 * @author  Alex Lopez <your.email@example.com>
 * @date    2024-11-26
 */


defined('MOODLE_INTERNAL') || die();

//require_once(__DIR__ . '/lib.php');
require_once($CFG->dirroot . '/mod/quiz/accessrule/plugin_dora/lib.php');


use mod_quiz\local\access_rule_base;
use mod_quiz\quiz_settings;


/**
 * The access rule class implementation for the quizaccess_plugin_dora plugin.
 * A rule that hijacks the standard attempt.php page, and replaces it with
 * different script which loads all the questions at once and then allows the
 * student to keep working, even if the network connection is lost. However,
 * if the network is working, responses are saved back to the server.
 *
 * @copyright 2014 The Open University
 * @license http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class quizaccess_plugin_dora extends quiz_access_rule_base {
    /**
     * @purpose Creates an instance of the access rule for the quiz, applying the necessary 
     *          restrictions and validation based on the plugin settings.
     * 
     * @param quiz $quizobj The quiz object that contains information about the quiz being accessed.
     * @param int $timenow The current timestamp used for time-based restrictions.
     * @param bool $canignoretimelimits Flag indicating if the user can ignore time limits.
     * 
     * @returns quizaccess_plugin_dora An instance of the class that defines the access rule for the quiz.
     */
    public static function make(quiz $quizobj, $timenow, $canignoretimelimits) {
 
        return new self($quizobj, $timenow);
    }
    /**
     * @purpose Adds configuration fields to the quiz settings form in the Moodle administration interface. 
     *          This allows administrators to adjust the plugin's access restrictions for each quiz.
     * 
     * @param mod_quiz_mod_form $quizform The form object for the quiz settings page.
     * @param MoodleQuickForm $mform The form object that fields are added to.
     * 
     * @returns void This function does not return any value.
     */
    public static function add_settings_form_fields(mod_quiz_mod_form $quizform, MoodleQuickForm $mform) {
        // Añadir una nueva configuración al formulario de configuración del cuestionario.
        global $DB;
        $quizinstance = $quizform->get_instance();
        $monitoring = new plugin_dora_functions();
        $monitoring_status = $monitoring->plugin_dora_getGlobalStatus();

        if ($monitoring_status) {
            $config = $DB->get_record('quizaccess_monitoring_settings', ['quizid' => $quizinstance]);

            $mform->addElement('header', 'plugin_dora_setting', get_string('plugin_dora_setting', 'quizaccess_plugin_dora'));
            $mform->addElement('selectyesno', 'plugin_dora_enable', get_string('plugin_dora_setting', 'quizaccess_plugin_dora'));
            $mform->addHelpButton('plugin_dora_enable', 'plugin_dora_setting', 'quizaccess_plugin_dora');
            $mform->setDefault('plugin_dora_enable', $config ? $config->plugin_dora_enable : 0);
            $mform->setType('plugin_dora_enable', PARAM_BOOL);

            // Lista de restricciones con tooltips.
            $restrictions = [
                'restriction_fullscreen' => 'Forzar pantalla completa',
                'restriction_print' => 'Bloquear impresión',
                'restriction_paste' => 'Bloquear pegar',
                'restriction_rightclick' => 'Bloquear clic derecho',
                'restriction_copy' => 'Bloquear copiar',
                'restriction_traslate' => 'Bloquear traducciones',
                'restriction_detectalt' => 'Detectar tecla ALT',
                'restriction_selecttext' => 'Deshabilitar selección de texto',
                'restriction_resize' => 'Bloquear redimensionamiento',
                'restriction_download' => 'Bloquear descargas',
                'restriction_onlinerecognition' => 'Habilitar reconocimiento facial',
                'single_monitor' => 'Permitir solo un monitor',
                'window_change' => 'Bloquear cambio de ventana',
                'deterrent_mode' => 'Activar modo disuasorio',
                'focus_exam' => 'Requiere atención constante',
            ];
    
            foreach ($restrictions as $key => $label) {
                // Añadir checkbox para cada restricción con su tooltip.
                $mform->addElement('checkbox', $key, get_string($key, 'quizaccess_plugin_dora'));
                $mform->addHelpButton($key, $key, 'quizaccess_plugin_dora'); // Tooltip para cada restricción.
                $mform->setDefault($key, $config && isset($config->$key) ? $config->$key : 0);
                $mform->disabledIf($key, 'plugin_dora_enable', 'eq', 0);
            }
        }
        
    }
    /**
     * @purpose Saves the plugin's settings for a specific quiz to the database, allowing the 
     *          restrictions to be applied whenever the quiz is attempted.
     * 
     * @param object $quiz The quiz object containing the settings to be saved.
     * 
     * @returns void This function does not return any value.
     */
    public static function save_settings($quiz) {
        global $DB;

        try {
            if (empty($quiz->plugin_dora_enable)) {
                // Si el quiz no será monitoreado, eliminamos su configuración.
                $DB->delete_records('quizaccess_monitoring_settings', ['quizid' => $quiz->id]);
                return;
            }

            // Inicializar el objeto de configuración
            $record = $DB->get_record('quizaccess_monitoring_settings', ['quizid' => $quiz->id]) ?: new stdClass();
            $record->quizid = $quiz->id;
            $record->plugin_dora_enable = 1;

            // Lista de restricciones a verificar
            $restrictionKeys = [
                'restriction_fullscreen', 'restriction_print', 'restriction_paste', 'restriction_rightclick',
                'restriction_copy', 'restriction_traslate', 'restriction_detectalt', 'restriction_selecttext',
                'restriction_resize', 'restriction_download', 'restriction_onlinerecognition', 'single_monitor',
                'window_change', 'deterrent_mode', 'focus_exam'
            ];

            // Asignar valores con fallback a 0 si están vacíos o no definidos
            foreach ($restrictionKeys as $key) {
                $record->$key = !empty($quiz->$key) ? $quiz->$key : 0;
            }
//            $record->isquizstarted = 0;

            // Insertar o actualizar registro según corresponda
            if (!$DB->record_exists('quizaccess_monitoring_settings', ['quizid' => $quiz->id])) {
                $DB->insert_record('quizaccess_monitoring_settings', $record);
            } else {
                $DB->update_record('quizaccess_monitoring_settings', $record);
            }

            // Enviar configuración a la API
            self::send_to_api_quiz($quiz);
        } catch (Exception $e) {
            debugging("Error en save_settings: " . $e->getMessage(), DEBUG_DEVELOPER);
        }
    }

//    public static function save_settings($quiz) {
//        // debugging("Entro_Save", DEBUG_DEVELOPER); // Usar debugging() en lugar de error_log().
//        global $DB;
//
//        if (empty($quiz->plugin_dora_enable)) {
//            // El quiz no sera monitoreado
//            // debugging("no sera monitoreado", DEBUG_DEVELOPER);
//            $DB->delete_records('quizaccess_monitoring_settings', ['quizid' => $quiz->id]);
//            // print_object($quiz);
//        } else {
//
//            $record = new stdClass();
//            if (!$DB->record_exists('quizaccess_monitoring_settings', ['quizid' => $quiz->id])) {
//                $record->quizid = $quiz->id;
//            } else {
//                $record = $DB->get_record('quizaccess_monitoring_settings', ['quizid' => $quiz->id]);
//                self::send_to_api_quiz($quiz);
//            }
//            if (empty($quiz->restriction_fullscreen) || !$quiz->restriction_fullscreen) {
//                $quiz->restriction_fullscreen = 0;
//            }
//            if (empty($quiz->restriction_print) || !$quiz->restriction_print) {
//                $quiz->restriction_print = 0;
//            }
//            if (empty($quiz->restriction_paste) || !$quiz->restriction_paste) {
//                $quiz->restriction_paste = 0;
//            }
//            if (empty($quiz->restriction_rightclick) || !$quiz->restriction_rightclick) {
//                $quiz->restriction_rightclick = 0;
//            }
//            if (empty($quiz->restriction_copy) || !$quiz->restriction_copy) {
//                $quiz->restriction_copy = 0;
//            }
//            if (empty($quiz->restriction_traslate) || !$quiz->restriction_traslate) {
//                $quiz->restriction_traslate = 0;
//            }
//            if (empty($quiz->restriction_detectalt) || !$quiz->restriction_detectalt) {
//                $quiz->restriction_detectalt = 0;
//            }
//            if (empty($quiz->restriction_selecttext) || !$quiz->restriction_selecttext) {
//                $quiz->restriction_selecttext = 0;
//            }
//            if (empty($quiz->restriction_resize) || !$quiz->restriction_resize) {
//                $quiz->restriction_resize = 0;
//            }
//            if (empty($quiz->restriction_download) || !$quiz->restriction_download) {
//                $quiz->restriction_download = 0;
//            }
//            if (empty($quiz->restriction_onlinerecognition) || !$quiz->restriction_onlinerecognition) {
//                $quiz->restriction_onlinerecognition = 0;
//            }
//            if (empty($quiz->single_monitor) || !$quiz->single_monitor) {
//                $quiz->single_monitor = 0;
//            }
//            if (empty($quiz->window_change) || !$quiz->window_change) {
//                $quiz->window_change = 0;
//            }
//            if (empty($quiz->deterrent_mode) || !$quiz->deterrent_mode) {
//                $quiz->deterrent_mode = 0;
//            }
//            if (empty($quiz->focus_exam) || !$quiz->focus_exam) {
//                $quiz->focus_exam = 0;
//            }
//
//            $record->quizid = $quiz->id;
//            $record->plugin_dora_enable = 1;
//            $record->restriction_fullscreen = $quiz->restriction_fullscreen;
//            $record->restriction_print = $quiz->restriction_print;
//            $record->restriction_paste = $quiz->restriction_paste;
//            $record->restriction_rightclick = $quiz->restriction_rightclick;
//            $record->restriction_copy = $quiz->restriction_copy;
//            $record->restriction_traslate = $quiz->restriction_traslate;
//            $record->restriction_detectalt = $quiz->restriction_detectalt;
//            $record->restriction_selecttext = $quiz->restriction_selecttext;
//            $record->restriction_resize = $quiz->restriction_resize;
//            $record->restriction_download = $quiz->restriction_download;
//            $record->restriction_onlinerecognition = $quiz->restriction_onlinerecognition;
//            $record->single_monitor = $quiz->single_monitor;
//            $record->window_change = $quiz->window_change;
//            $record->deterrent_mode = $quiz->deterrent_mode;
//            $record->focus_exam = $quiz->focus_exam;
//            $record->isquizstarted = 0;
//
//            // $DB->insert_record('quizaccess_monitoring_settings', $record);
//            if (!$DB->record_exists('quizaccess_monitoring_settings', ['quizid' => $quiz->id])) {
//                $DB->insert_record('quizaccess_monitoring_settings', $record);
//                self::send_to_api_quiz($quiz);
//            } else {
//                $DB->update_record('quizaccess_monitoring_settings', $record);
//                self::send_to_api_quiz($quiz);
//            }
//        }
//    }

    /**
     * @purpose Sends the quiz configuration data to an external API for validation or storage.
     * 
     * @param object $quiz The quiz object containing configuration data to be sent to the API.
     * 
     * @returns void This function does not return any value.
     */
    public static function send_to_api_quiz($quiz) {
        global $DB, $CFG, $USER;

        // Obtener la configuración del plugin.
        $record = $DB->get_record('monitoring_integration', ['id' => 1]);
        if (!$record) {
            debugging("Error: No se encontró el registro de configuración de 'monitoring_integration'.", DEBUG_DEVELOPER);
            return false;
        }

        $moodlekey = $record->plugin_dora_key;
        if (empty($moodlekey)) {
            debugging("Error: La clave del plugin 'plugin_dora_key' está vacía.", DEBUG_DEVELOPER);
            return false;
        }

        $apiurl = 'https://pruebas.w-techsas.com/api/plugin/register-quiz'; // URL de la API.

        // Obtener el curso del quiz.
        $course = $DB->get_record('course', ['id' => $quiz->course]);
        if (!$course) {
            debugging("Error: No se encontró el curso con ID {$quiz->course}.", DEBUG_DEVELOPER);
            return false;
        }

        $coursename = $course->fullname;
        $institutionurl = $CFG->wwwroot; // URL de Moodle
        $courseid = $quiz->course;

        // Generar la URL del quiz.
        $urlquiz = new moodle_url('/mod/quiz/attempt.php', ['cmid' => $quiz->coursemodule]);

        // Obtener restricciones activadas.
        $restrictions = [];
        $restrictionKeys = [
            'restriction_fullscreen' => 'fullScreen',
            'restriction_print' => 'print',
            'restriction_paste' => 'paste',
            'restriction_rightclick' => 'rightClick',
            'restriction_copy' => 'copy',
            'restriction_traslate' => 'translate',
            'restriction_detectalt' => 'detectAlt',
            'restriction_selecttext' => 'selectText',
            'restriction_resize' => 'resize',
            'restriction_download' => 'download',
            'restriction_onlinerecognition' => 'onlineRecognition',
            'single_monitor' => 'oneMonitor',
            'window_change' => 'windowChange',
            'deterrent_mode' => 'deterrentMode',
            'focus_exam' => 'focusExam'
        ];
        foreach ($restrictionKeys as $key => $name) {
            if (!empty($quiz->$key)) {
                $restrictions[] = $name;
            }
        }

        // Datos a enviar.
        $postdata = [
            "institutionUrl" => $institutionurl,
            "moodleCourseName" => $coursename,
            "moodleCourseId" => $courseid,
            "nameQuiz" => $quiz->name,
            "moodleQuizId" => (string) $quiz->id,
            "urlQuiz" => $urlquiz->out(false),
            "restrictions" => $restrictions,
        ];
        $jsondata = json_encode($postdata);

        // Configurar curl.
        $ch = curl_init($apiurl);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $jsondata,
            CURLOPT_HTTPHEADER => [
                'Content-Type: application/json',
                'Content-Length: ' . strlen($jsondata),
                'x-moodle-key: ' . $moodlekey,
                'x-moodle-url: ' . $institutionurl,
            ],
            CURLOPT_TIMEOUT => 10,
            CURLOPT_CONNECTTIMEOUT => 5,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
        ]);

        // Ejecutar la solicitud y manejar la respuesta.
        $response = curl_exec($ch);
        $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlerror = curl_error($ch);
        curl_close($ch);

        if ($response === false) {
            debugging("Error al enviar los datos a la API: $curlerror", DEBUG_DEVELOPER);
            return false;
        }

        debugging("Respuesta de la API: $response", DEBUG_DEVELOPER);

        if ($httpcode === 200) {
            if (!empty($USER->id)) {
                $quizcreatorid = $USER->id;
                $quizcreator = $DB->get_record('user', ['id' => $quizcreatorid]);
                if ($quizcreator) {
                    self::send_to_api_user($quizcreator, $quiz);
                } else {
                    debugging("Error: No se encontró al usuario creador del quiz con ID $quizcreatorid.", DEBUG_DEVELOPER);
                }
            } else {
                debugging("Error: No se pudo obtener el usuario actual.", DEBUG_DEVELOPER);
            }
            return true;
        } else {
            debugging("La API respondió con un estado HTTP $httpcode.", DEBUG_DEVELOPER);
            return false;
        }
    }

//    public static function send_to_api($quiz) {
//        global $DB, $CFG;
//
//        $record = $DB->get_record('monitoring_integration', array('id' => 1));
//        $moodlekey = $record->plugin_dora_key;
//
//        $apiurl = 'hhttps://apidora.aionis.net/api/plugin/register-quiz'; // URL de la API.
//
//        // Obtener el curso del quiz usando el courseid.
//        $course = $DB->get_record('course', ['id' => $quiz->course], '*', MUST_EXIST);
//        $coursename = $course->fullname;
//
//        // Obtener la url de la instancia moodle
//        $institutionurl = $CFG->wwwroot; // Obtiene la URL de la instancia de Moodle
//
//        // Obtener el ID del curso
//        $courseid = $quiz->course;
//
//        // Generar la URL del quiz.
//        $urlquiz = new moodle_url('/mod/quiz/attempt.php', ['cmid' => $quiz->coursemodule]);
//        // Inicializa un arreglo vacío para las restricciones.
//        $restrictions = [];
//
//        // Solo añade los nombres de las restricciones seleccionadas.
//        if (!empty($quiz->restriction_fullscreen)) {
//            $restrictions[] = 'fullScreen';
//        }
//        if (!empty($quiz->restriction_print)) {
//            $restrictions[] = 'print';
//        }
//        if (!empty($quiz->restriction_paste)) {
//            $restrictions[] = 'paste';
//        }
//        if (!empty($quiz->restriction_rightclick)) {
//            $restrictions[] = 'rightClick';
//        }
//        if (!empty($quiz->restriction_copy)) {
//            $restrictions[] = 'copy';
//        }
//        if (!empty($quiz->restriction_traslate)) {
//            $restrictions[] = 'translate';
//        }
//        if (!empty($quiz->restriction_detectalt)) {
//            $restrictions[] = 'detectAlt';
//        }
//        if (!empty($quiz->restriction_selecttext)) {
//            $restrictions[] = 'selectText';
//        }
//        if (!empty($quiz->restriction_resize)) {
//            $restrictions[] = 'resize';
//        }
//        if (!empty($quiz->restriction_download)) {
//            $restrictions[] = 'download';
//        }
//        if (!empty($quiz->restriction_onlinerecognition)) {
//            $restrictions[] = 'onlineRecognition';
//        }
//        if (!empty($quiz->single_monitor)) {
//            $restrictions[] = 'oneMonitor';
//        }
//        if (!empty($quiz->window_change)) {
//            $restrictions[] = 'windowChange';
//        }
//        if (!empty($quiz->deterrent_mode)) {
//            $restrictions[] = 'deterrentMode';
//        }
//        if (!empty($quiz->focus_exam)) {
//            $restrictions[] = 'focusExam';
//        }
//
//        // Datos a enviar
//
//        $postdata = [
//            "institutionUrl" => $institutionurl,
//            "moodleCourseName" => $coursename,
//            "moodleCourseId" => $courseid,
//            "nameQuiz" => $quiz->name,
//            "moodleQuizId" => (string) $quiz->id,
//            "urlQuiz" => $urlquiz->out(false),
//            "restrictions" => $restrictions, // Enviar solo los nombres de las restricciones seleccionadas.
//        ];
//        // Convierte los datos a formato JSON.
//        $jsondata = json_encode($postdata);
//
//        // Usar curl para hacer la solicitud POST a la API.
//        $ch = curl_init($apiurl);
//
//        curl_setopt_array($ch, [
//            CURLOPT_RETURNTRANSFER => true,
//            CURLOPT_POST => true,
//            CURLOPT_POSTFIELDS => $jsondata,
//            CURLOPT_HTTPHEADER => [
//                'Content-Type: application/json',
//                'Content-Length: ' . strlen($jsondata),
//                'x-moodle-key: ' . $moodlekey,
//                'x-moodle-url: ' . $institutionurl,
//            ],
//            CURLOPT_TIMEOUT => 10, // Tiempo de espera de 10 segundos
//            CURLOPT_CONNECTTIMEOUT => 5, // Tiempo de espera para conectar
//
//            // Configuración SSL
//            CURLOPT_SSL_VERIFYPEER => false, // Verificar el certificado SSL
//            CURLOPT_SSL_VERIFYHOST => 2, // Verificar que el host coincida con el certificado
//
//            // Si estás en un entorno local con XAMPP/WAMP, descomenta esta línea:
////        CURLOPT_CAINFO => $CFG->dirroot . '/cacert.pem',
//        ]);
//
////        // Configurar curl.
////        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
////        curl_setopt($ch, CURLOPT_POST, true);
////        curl_setopt($ch, CURLOPT_POSTFIELDS, $jsondata);
////        curl_setopt($ch, CURLOPT_HTTPHEADER, [
////            'Content-Type: application/json',
////            'Content-Length: ' . strlen($jsondata),
////            'x-moodle-key: ' . $moodlekey,
////            'x-moodle-url: ' . $institutionurl,
////        ]);
//
//        // Ejecutar la solicitud y obtener la respuesta
//        $response = curl_exec($ch);
//        $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE); // Obtener el código de respuesta HTTP.
//        if ($response === false) {
//            $error = curl_error($ch);
//            debugging("Error al enviar los datos a la API: $error", DEBUG_DEVELOPER);
//        } else {
//            debugging("Respuesta de la API: $response", DEBUG_DEVELOPER); // Mostrar la respuesta para propósitos de depuración.
//            // Verificar si la respuesta es 200 OK.
//            if ($httpcode == 200) {
//                global $USER, $DB;
//
//                if (!empty($USER->id)) {
//                    $quizcreatorid = $USER->id;  // ID del usuario creador
//                    $quizcreator = $DB->get_record('user', ['id' => $quizcreatorid], '*', MUST_EXIST);
//
//                    // Llama a la función para registrar al usuario creador y enviar a la API.
//                    self::send_to_api_user($quizcreator, $quiz);
//                } else {
//                    debugging("No se pudo obtener el usuario actual que creó el quiz.", DEBUG_DEVELOPER);
//                }
//            } else {
//                debugging("La API respondió con un estado diferente a 200: $httpcode", DEBUG_DEVELOPER);
//            }
//        }
//
//        // Cerrar la sesión curl.
//        curl_close($ch);
//    }
    /**
     * Enviar la información del usuario a una API externa.
     *
     * @param object $user Datos del usuario.
     * @param object $quiz Datos del quiz.
     */
    public static function send_to_api_user($user, $quiz) {
        global $DB, $CFG;

        // Obtener la configuración del plugin
        $record = $DB->get_record('monitoring_integration', array('id' => 1));
        if (!$record || empty($record->plugin_dora_key)) {
            debugging("Error: No se encontró la clave de API en la tabla 'monitoring_integration'", DEBUG_DEVELOPER);
            return false;
        }

        $moodlekey = $record->plugin_dora_key;
        $institutionurl = $CFG->wwwroot; // URL de Moodle

        // Obtener curso y contexto
        $course = $DB->get_record('course', ['id' => $quiz->course], '*', MUST_EXIST);
        $context = context_course::instance($course->id);

        // Obtener rol del usuario
        $roles = get_user_roles($context, $user->id, true);
        $userrole = !empty($roles) ? role_get_name(reset($roles)) : 'Sin rol';

        // Normalizar el rol del usuario
        $userrole = strtolower($userrole);
        if ($userrole === 'estudiante' || $userrole === 'student') {
            $userrole = 'student';
        } else {
            $userrole = 'teacher';
        }

        // Datos a enviar
        $postdata = [
            "institutionUrl" => $institutionurl,
            "documentNumber" => $user->id,
            "userName" => fullname($user),
            "userMail" => $user->email,
            "userTypeName" => $userrole,
            "moodleQuizId" => (string) $quiz->id,
        ];

        // Convertir a JSON
        $jsondata = json_encode($postdata);
        if ($jsondata === false) {
            debugging("Error al codificar JSON: " . json_last_error_msg(), DEBUG_DEVELOPER);
            return false;
        }

        // URL de la API
        $apiurl = 'https://pruebas.w-techsas.com/api/plugin/register-user';

        // Configuración de cURL
        $ch = curl_init($apiurl);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $jsondata,
            CURLOPT_HTTPHEADER => [
                'Content-Type: application/json',
                'Content-Length: ' . strlen($jsondata),
                'x-moodle-key: ' . $moodlekey,
                'x-moodle-url: ' . $institutionurl,
            ],
            CURLOPT_TIMEOUT => 10,
            CURLOPT_CONNECTTIMEOUT => 5,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
        ]);

        // Ejecutar la solicitud y obtener respuesta
        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);

        // Manejo de errores de cURL
        if ($response === false) {
            $error = curl_error($ch);
            debugging("Error en cURL: $error", DEBUG_DEVELOPER);
            curl_close($ch);
            return false;
        }

        // Verificar código de respuesta HTTP
        if ($http_code >= 400) {
            debugging("Error HTTP $http_code en la API: $response", DEBUG_DEVELOPER);
            curl_close($ch);
            return false;
        }

        // Decodificar respuesta JSON
        $decoded_response = json_decode($response, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            debugging("Error al decodificar JSON: " . json_last_error_msg(), DEBUG_DEVELOPER);
            curl_close($ch);
            return false;
        }

        // Cerrar conexión cURL
        curl_close($ch);

        // Registrar éxito en el debugging
        debugging("Usuario registrado correctamente: " . json_encode($decoded_response), DEBUG_DEVELOPER);

        return $decoded_response;
    }

//    public static function send_to_api_user($user, $quiz) {
//        global $DB, $CFG;
//
//        $record = $DB->get_record('monitoring_integration', array('id' => 1));
//        $moodlekey = $record->plugin_dora_key;
//
//        $institutionurl = $CFG->wwwroot; // Obtiene la URL de la instancia de Moodle
//        // Obtener el curso al que pertenece el quiz.
//        $course = $DB->get_record('course', ['id' => $quiz->course], '*', MUST_EXIST);
//
//        // Obtener el contexto del curso.
//        $context = context_course::instance($course->id);
//
//        // Obtener el rol del usuario.
//        $roles = get_user_roles($context, $user->id, true);
//        $userrole = !empty($roles) ? role_get_name(reset($roles)) : 'Sin rol';
//
//        // Normalizar el rol.
//        if ($userrole == 'Estudiante') {
//            $userrole = 'student';
//        } else if ($userrole == 'Profesor') {
//            $userrole = 'teacher';
//        } else {
//            $userrole = 'teacher';
//        }
//
//        // Preparar los datos a enviar.
//        $postdata = [
//            "institutionUrl" => $institutionurl,  // URL de la institución.
//            "documentNumber" => $user->id,  // ID del usuario (documento).
//            "userName" => fullname($user),  // Nombre completo del usuario.
//            "userMail" => $user->email,  // Correo electrónico del usuario.
//            "userTypeName" => $userrole,  // Rol del usuario.
//            "moodleQuizId" => (string) $quiz->id,  // ID del quiz.
//        ];
//
//        // Convertir a JSON.
//        $jsondata = json_encode($postdata);
//        print_object($jsondata);
//        // URL de la API para registrar al usuario.
//        $apiurl = 'https://apidora.aionis.net/api/plugin/register-user';
//
//        // Usar curl para hacer la solicitud POST.
//        $ch = curl_init($apiurl);
//        curl_setopt_array($ch, [
//            CURLOPT_RETURNTRANSFER => true,
//            CURLOPT_POST => true,
//            CURLOPT_POSTFIELDS => $jsondata,
//            CURLOPT_HTTPHEADER => [
//                'Content-Type: application/json',
//                'Content-Length: ' . strlen($jsondata),
//                'x-moodle-key: ' . $moodlekey,
//                'x-moodle-url: ' . $institutionurl,
//            ],
//            CURLOPT_TIMEOUT => 10, // Tiempo de espera de 10 segundos
//            CURLOPT_CONNECTTIMEOUT => 5, // Tiempo de espera para conectar
//
//            // Configuración SSL
//            CURLOPT_SSL_VERIFYPEER => false, // Verificar el certificado SSL
//            CURLOPT_SSL_VERIFYHOST => 2, // Verificar que el host coincida con el certificado
//
//            // Si estás en un entorno local con XAMPP/WAMP, descomenta esta línea:
////        CURLOPT_CAINFO => $CFG->dirroot . '/cacert.pem',
//        ]);
////        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
////        curl_setopt($ch, CURLOPT_POST, true);
////        curl_setopt($ch, CURLOPT_POSTFIELDS, $jsondata);
////        curl_setopt($ch, CURLOPT_HTTPHEADER, [
////            'Content-Type: application/json',
////            'Content-Length: ' . strlen($jsondata),
////            'x-moodle-key: ' . $moodlekey,
////            'x-moodle-url: ' . $institutionurl,
////        ]);
//
//        // Ejecutar la solicitud.
//        $response = curl_exec($ch);
//
//        if ($response === false) {
//            $error = curl_error($ch);
//            debugging("Error al registrar el usuario: $error", DEBUG_DEVELOPER);
//        } else {
//            debugging("Usuario registrado en la API: $response", DEBUG_DEVELOPER);
//        }
//
//        // Cerrar curl.
//        curl_close($ch);
//    }
}

